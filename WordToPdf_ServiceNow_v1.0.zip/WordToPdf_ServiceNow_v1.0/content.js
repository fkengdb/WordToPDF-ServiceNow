(function() {
    // Verifica se já existe para evitar duplicidade
    if (window.hasTIMConverterLoaded) return;
    window.hasTIMConverterLoaded = true;

    // Só injeta se a tela for grande o suficiente (evita frames de botões e chats)
    if (window.innerHeight < 300) return;

    const init = () => {
        const dropZone = document.createElement('div');
        dropZone.id = 'word-converter-float';
        // Usamos estilos inline para garantir que o ServiceNow não sobrescreva
        dropZone.setAttribute('style', 'position:fixed !important; bottom:20px !important; right:20px !important; z-index:2147483647 !important; display:flex !important; flex-direction:column !important; align-items:center !important; justify-content:center !important; fit-content !important; height:fit-content!important; background:#9013FE !important; color:white !important; 1.2rem !important; font-family:sans-serif !important; cursor:pointer !important; box-shadow:0 4px 15px rgba(0,0,0,0.3) !important; padding:10px !important; border: none !important');
        
        dropZone.innerHTML = `
            <div id="status-text" style="font-size:12px; font-weight:bold; pointer-events:none;">.docx</div>
            <div id="prog-cont" style="display:none; width:fit-content !important; height:fit-content !important; background:rgba(255,255,255,0.2); border-radius:4px; margin:10px 0; overflow:hidden;">
                <div id="prog-bar" style="width:0%; height:100%; background:#00d300; transition:width 0.3s;"></div>
            </div>
            <div id="credit-count" style="font-size:10px; opacity:0.8; margin-top:5px; pointer-events:none;">Carregando créditos...</div>
        `;
        
        document.body.appendChild(dropZone);

        // Previne comportamento padrão do navegador
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(name => {
            window.addEventListener(name, e => {
                if (e.target.id === 'word-converter-float') {
                    e.preventDefault();
                    e.stopPropagation();
                }
            }, false);
        });

        dropZone.addEventListener('drop', handleDrop);
        
        // Pede créditos com um pequeno atraso para o Background estar pronto
        setTimeout(() => chrome.runtime.sendMessage({ action: 'get_credits' }), 1000);
    };

    async function handleDrop(e) {
        const file = e.dataTransfer.files[0];
        const url = e.dataTransfer.getData('text/uri-list');
        const statusText = document.getElementById('status-text');

        if (file || url) {
            document.getElementById('prog-cont').style.display = 'block';
            if (file) {
                sendToConvert(file, file.name);
            } else {
                statusText.innerText = "Baixando link...";
                try {
                    const r = await fetch(url);
                    const b = await r.blob();
                    sendToConvert(b, "documento.docx");
                } catch(err) { statusText.innerText = "Erro no link"; }
            }
        }
    }

    function sendToConvert(blob, name) {
        const reader = new FileReader();
        reader.onload = (e) => {
            chrome.runtime.sendMessage({ action: 'convert_file', fileData: e.target.result, fileName: name });
        };
        reader.readAsDataURL(blob);
    }

    chrome.runtime.onMessage.addListener((m) => {
        const txt = document.getElementById('status-text');
        const bar = document.getElementById('prog-bar');
        const cred = document.getElementById('credit-count');

        if (m.action === 'update_status' && txt && bar) {
            txt.innerText = `${m.text} (${m.percent}%)`;
            bar.style.width = `${m.percent}%`;
            if (m.percent >= 100) setTimeout(() => {
                document.getElementById('prog-cont').style.display = 'none';
                txt.innerText = ".docx";
            }, 3000);
        }
        if (m.action === 'update_credits' && cred) {
            cred.innerText = m.count !== null ? `Créditos restantes: ${m.count}` : "Não foi possível buscar os créditos";
        }
    });

    if (document.readyState === 'complete') init();
    else window.addEventListener('load', init);
})();