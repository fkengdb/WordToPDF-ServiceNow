document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get('ilovePdfKey', (data) => {
        if (data.ilovePdfKey) document.getElementById('key').value = data.ilovePdfKey;
    });

    document.getElementById('save').addEventListener('click', () => {
        const key = document.getElementById('key').value;
        chrome.storage.local.set({ ilovePdfKey: key }, () => {
            alert('Chave salva!');
            window.close();
        });
    });
});