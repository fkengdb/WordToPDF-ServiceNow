const API_BASE = 'https://api.ilovepdf.com/v1';

// Função para buscar créditos
async function fetchCredits(token) {
    try {
        const res = await fetch(`${API_BASE}/user`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!res.ok) return null; // Segurança caso o token expire rápido
        const data = await res.json();
        return data.files_limit - data.files_used;
    } catch (e) { return null; }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    const tabId = sender.tab?.id;

    if (request.action === 'get_credits') {
        handleCreditsRequest(tabId);
    }

    if (request.action === 'convert_file') {
        handleConversion(request.fileData, request.fileName, tabId);
    }
    return true; // Mantém o canal aberto para operações assíncronas
});

async function handleCreditsRequest(tabId) {
    if (!tabId) return;
    const settings = await chrome.storage.local.get('ilovePdfKey');
    
    if (!settings.ilovePdfKey) {
        chrome.tabs.sendMessage(tabId, { action: 'update_credits', count: null });
        return;
    }

    try {
        const authRes = await fetch(`${API_BASE}/auth`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ public_key: settings.ilovePdfKey })
        });

        if (!authRes.ok) {
            chrome.tabs.sendMessage(tabId, { action: 'update_credits', count: "Erro de Chave" });
            return;
        }

        const { token } = await authRes.json();
        const count = await fetchCredits(token);
        chrome.tabs.sendMessage(tabId, { action: 'update_credits', count: count });

    } catch (e) {
        chrome.tabs.sendMessage(tabId, { action: 'update_credits', count: "Erro API" });
    }
}

async function handleConversion(fileData, fileName, tabId) {
    const sendStatus = (text, percent) => {
        chrome.tabs.sendMessage(tabId, { action: 'update_status', text, percent });
    };

    try {
        const settings = await chrome.storage.local.get('ilovePdfKey');
        if (!settings.ilovePdfKey) {
            sendStatus("Erro: Sem API Key", 0);
            return;
        }

        // 1. Auth
        sendStatus("Autenticando...", 10);
        const authRes = await fetch(`${API_BASE}/auth`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ public_key: settings.ilovePdfKey })
        });
        const { token } = await authRes.json();

        // 2. Start
        sendStatus("Iniciando...", 25);
        const startRes = await fetch(`${API_BASE}/start/officepdf`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const { server, task } = await startRes.json();

        // 3. Upload
        sendStatus("Upload...", 50);
        const blob = await (await fetch(fileData)).blob();
        const formData = new FormData();
        formData.append('task', task);
        formData.append('file', blob, fileName);
        const upRes = await fetch(`https://${server}/v1/upload`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: formData
        });
        const { server_filename } = await upRes.json();

        // 4. Process
        sendStatus("Convertendo...", 80);
        const procRes = await fetch(`https://${server}/v1/process`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                task, tool: 'officepdf', 
                files: [{ server_filename, filename: fileName }] 
            })
        });
        
        // Verificação extra de sucesso no processamento
        if (!procRes.ok) throw new Error("Falha no processamento");

        // 5. Download
        sendStatus("Baixando...", 95);
        const dlRes = await fetch(`https://${server}/v1/download/${task}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const pdfBlob = await dlRes.blob();
        
        const reader = new FileReader();
        reader.onload = () => {
            chrome.downloads.download({
                url: reader.result,
                filename: fileName.replace(/\.docx?$/i, '.pdf')
            });
            sendStatus("Sucesso!", 100);
            
            // Pequeno atraso para a API atualizar o contador de uso no servidor
            setTimeout(() => handleCreditsRequest(tabId), 2000);
        };
        reader.readAsDataURL(pdfBlob);

    } catch (e) {
        console.error(e);
        sendStatus("Erro na conversão", 0);
    }
}